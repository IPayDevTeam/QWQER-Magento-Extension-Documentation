<?php

namespace Qwqer\Delivery\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;

class Settings extends AbstractHelper
{
    /** @var ScopeConfigInterface */
    protected $scopeConfig;

    public function __construct(Context $context, ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
        parent::__construct($context);
    }

    public function getConfig(): ScopeConfigInterface
    {
        return $this->scopeConfig;
    }

    public function getSettings(): array
    {
        return [
            'status' => $this->scopeConfig->getValue('qwqer/general/enable'),
            'login' => $this->scopeConfig->getValue('qwqer/access/login'),
            'password' => $this->scopeConfig->getValue('qwqer/access/password'),
        ];
    }

    public function getStoreAddress(): array
    {
        return [
            'address' => $this->scopeConfig->getValue('qwqer/address/address'),
            'country' => $this->scopeConfig->getValue('qwqer/address/country'),
            'countrycode2' => $this->scopeConfig->getValue('qwqer/address/countrycode2'),
            'city' => $this->scopeConfig->getValue('qwqer/address/city'),
            'citycode2' => $this->scopeConfig->getValue('qwqer/address/citycode2'),
            'zipcode' => $this->scopeConfig->getValue('qwqer/address/zipcode'),
            'state' => $this->scopeConfig->getValue('qwqer/address/state'),
            'statecode' => $this->scopeConfig->getValue('qwqer/address/statecode'),
            'region' => $this->scopeConfig->getValue('qwqer/address/region'),
            'regioncode2' => $this->scopeConfig->getValue('qwqer/address/regioncode2'),
        ];
    }
}
