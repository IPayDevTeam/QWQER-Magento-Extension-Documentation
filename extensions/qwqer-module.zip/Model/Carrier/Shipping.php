<?php

namespace Qwqer\Delivery\Model\Carrier;

use Magento\Framework\App\ObjectManager;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Shipping\Model\Carrier\AbstractCarrier;
use Magento\Shipping\Model\Carrier\CarrierInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory;
use Magento\Shipping\Model\Rate\Result;
use Psr\Log\LoggerInterface;
use Magento\Shipping\Model\Rate\ResultFactory;
use Magento\Quote\Model\Quote\Address\RateResult\MethodFactory;
use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Checkout\Model\Session;
use Qwqer\Delivery\Helper\Request;
use Qwqer\Delivery\Helper\Settings;
use Exception;
use Qwqer\Delivery\Model\Cache;
use Qwqer\Delivery\Model\ResourceModel\Cache\Collection;

class Shipping extends AbstractCarrier implements CarrierInterface
{
    /** @var Settings */
    protected $settingsHelper;

    /** @var Request */
    protected $requestHelper;

    /** @var Session */
    protected $session;

    /**
     * @var string
     */
    protected $_code = 'qwqerdeliveryshipping';

    /**
     * @var bool
     */
    protected $_isFixed = false;

    /**
     * @var ResultFactory
     */
    protected $_rateResultFactory;

    /**
     * @var MethodFactory
     */
    protected $_rateMethodFactory;

    /**
     * Shipping constructor.
     * @param ScopeConfigInterface $scopeConfig
     * @param ErrorFactory $rateErrorFactory
     * @param LoggerInterface $logger
     * @param ResultFactory $rateResultFactory
     * @param MethodFactory $rateMethodFactory
     * @param Session $session
     * @param Settings $settingsHelper
     * @param Request $requestHelper
     * @param array $data
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        ErrorFactory $rateErrorFactory,
        LoggerInterface $logger,
        ResultFactory $rateResultFactory,
        MethodFactory $rateMethodFactory,
        Session $session,
        Settings $settingsHelper,
        Request $requestHelper,
        array $data = []
    ) {
        $this->_rateResultFactory = $rateResultFactory;
        $this->_rateMethodFactory = $rateMethodFactory;
        $this->session = $session;

        $this->settingsHelper = $settingsHelper;
        $this->requestHelper = $requestHelper;

        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
    }

    /**
     * @return array
     */
    public function getAllowedMethods()
    {
        return [$this->_code => $this->getConfigData('name')];
    }

    /**
     * @return false|float|int
     */
    private function getShippingPrice()
    {
        $configPrice = $this->getConfigData('price');

        if (!$configPrice) {
            return false;
        }

        $shippingPrice = $this->getFinalPriceWithHandlingFee($configPrice);

        return $shippingPrice;
    }

    /**
     * @param RateRequest $request
     * @return false|Result
     */
    public function collectRates(RateRequest $request)
    {
        if (!$this->getConfigFlag('active')) {
            return false;
        }

        /** @var Result $result */
        $result = $this->_rateResultFactory->create();

        /** @var \Magento\Quote\Model\Quote\Address\RateResult\Method $method */
        $method = $this->_rateMethodFactory->create();

        $method->setCarrier($this->_code);
        $method->setCarrierTitle($this->getConfigData('title'));

        $method->setMethod($this->_code);
        $method->setMethodTitle($this->getConfigData('name'));

        $amount = $this->getShippingPrice();

        if ($amount === false) {
            $amount = $this->fetchPrice($request);

            if ($amount === false) {
                return false;
            }
        }

        $method->setPrice($amount);
        $method->setCost($amount);

        $result->append($method);

        return $result;
    }

    /**
     * @param RateRequest $request
     * @return false|float
     * @throws LocalizedException
     * @throws NoSuchEntityException
     */
    protected function fetchPrice(RateRequest $request)
    {
        // QWQER Settings and credentials
        $settings = $this->settingsHelper->getSettings();


        // Sender Address field
        $sender = $this->settingsHelper->getStoreAddress();
        $sender_address = array_filter([
            $sender['address'],
            $sender['city'],
            $sender['country'],
            $sender['state'] ?? null,
            $sender['region'] ?? null,
            $sender['zipcode'],
        ]);


        // Order
        $orderShippingAddress = $this->session->getQuote()->getShippingAddress()->getData();


        // Receiver Address field
        $receiver = [
            'address' => $orderShippingAddress['street'][0],
            'city' => $orderShippingAddress['city'],
            'country' => $orderShippingAddress['country_id'],
            'zipcode' => $orderShippingAddress['postcode'],
        ];
        $receiver_address = array_filter([
            $receiver['address'],
            $receiver['city'],
            $receiver['country'],
            // $request->getDestRegionCode() ?? null,
            // $receiver['region'] ?? null,
            $receiver['zipcode'],
        ]);


        // Cache check
        $hash = md5(implode('.', $sender_address) . ':' . implode('.', $receiver_address));
        
        $objectManager = ObjectManager::getInstance();
        $cacheResourceFactory = $objectManager->create(Cache::class);
        $cacheCollectionFactory = $objectManager->create(Collection::class);
        $cacheCollection = $cacheCollectionFactory
            ->addFieldToFilter('type', ['eq' => 'ShippingAddress'])
            ->addFieldToFilter('hash', ['eq' => $hash]);
        if ($cacheCollection->getSize()) {
            if (time() - strtotime($cacheCollection->getFirstItem()->getUpdatedAt()) <= (60 * 60 * 24 * 30)) {
                $cacheResourceFactory = $cacheCollection->getFirstItem();
                $payload = json_decode($cacheResourceFactory->getPayload(), true);

                if ($payload['distance'] > 40000) {
                    return false;
                }

                return $payload['price'];
            }
        }


        // Login to QWQER Api
        try {
            $loginResponse = $this->requestHelper->post('/api/xr/mch/login', [
                'login' => $settings['login'],
                'passw' => $settings['password'],
            ]);
        } catch (Exception $exception) {
            return false;
        }


        // Logged session token
        $token = $loginResponse['data']['restid'];


        // Get shipping order price from QWQER Api
        try {
            $deliveryOrderPriceResponse = $this->requestHelper->post('/api/xr/mch/delivery_price', [
                'sender' => array_merge([
                    'name' => $this->settingsHelper->getConfig()->getValue('trans_email/ident_general/name'),
                    'phone' => $this->settingsHelper->getConfig()->getValue('general/store_information/phone'),
                    'contact' => $this->settingsHelper->getConfig()->getValue('general/store_information/phone'),
                    'email' => $this->settingsHelper->getConfig()->getValue('trans_email/ident_general/email'),
                    'company' => $this->settingsHelper->getConfig()->getValue('general/store_information/name'),
                ], $sender, [
                    'address' => implode(', ', $sender_address),
                ]),
                'receiver' => array_merge([
                    'name' => trim($orderShippingAddress['firstname'] . ' ' . $orderShippingAddress['lastname']),
                    'contact' => $orderShippingAddress['telephone'],
                    'phone' => $orderShippingAddress['telephone'],
                    'email' => $orderShippingAddress['email'],
                    'company' => $orderShippingAddress['company'],
                ], $receiver, [
                    'address' => implode(', ', $receiver_address),
                ]),
                // @TODO add parcel sizes
                'ordersize' => [
                    'length' => 0,
                    'width' => 0,
                    'height' => 0,
                    'weight' => 1, // @TODO improve it, just count all products weight
                    'lenunit' => 'CENTIMETER',
                    'weightunit' => 'KILOGRAM',
                ],
            ], [
                "Authorization: Bearer {$token}",
            ]);
        } catch (Exception $exception) {
            return false;
        }

        $deliveryOrderPriceResponse['data']['price'] = (float)$deliveryOrderPriceResponse['data']['price'];

        $cacheResourceFactory->setData([
            'type' => 'ShippingAddress',
            'hash' => $hash,
            'payload' => json_encode($deliveryOrderPriceResponse['data']),
        ])->save();

        if ($deliveryOrderPriceResponse['data']['distance'] > 40000) {
            return false;
        }

        return $deliveryOrderPriceResponse['data']['price'];
    }
}
