<?php

namespace Qwqer\Delivery\Model\ResourceModel\Cache;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Qwqer\Delivery\Model\Cache;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'cache_id';
    protected $_eventPrefix = 'qwqer_delivery_cache_collection';
    protected $_eventObject = 'cache_collection';

    protected function _construct()
    {
        $this->_init(Cache::class, \Qwqer\Delivery\Model\ResourceModel\Cache::class);
    }
}
