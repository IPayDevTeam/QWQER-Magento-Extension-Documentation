<?php

namespace Qwqer\Delivery\Model;

use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\Model\AbstractModel;

class Cache extends AbstractModel implements IdentityInterface
{
    const CACHE_TAG = 'qwqer_delivery_cache';

    protected $_cacheTag = 'qwqer_delivery_cache';

    protected $_eventPrefix = 'qwqer_delivery_cache';

    protected function _construct()
    {
        $this->_init(ResourceModel\Cache::class);
    }

    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }
}
