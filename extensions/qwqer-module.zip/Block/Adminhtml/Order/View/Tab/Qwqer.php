<?php

namespace Qwqer\Delivery\Block\Adminhtml\Order\View\Tab;

use Magento\Backend\Block\Template;
use Magento\Backend\Block\Template\Context;
use Magento\Backend\Block\Widget\Tab\TabInterface;
use Magento\Directory\Model\Country;
use Magento\Framework\Registry;
use Qwqer\Delivery\Helper\Settings;

class Qwqer extends Template implements TabInterface
{
    protected $_template = 'view/order/qwqer.phtml';

    /** @var Registry */
    protected $_coreRegistry;

    /** @var Settings */
    protected $settingsHelper;

    /** @var Country */
    protected $countryModel;

    /** @var array */
    public $orderShippingAddress;

    public function __construct(
        Context $context,
        Registry $registry,
        Settings $settingsHelper,
        Country $countryModel,
        array $data = []
    )
    {
        $this->_coreRegistry = $registry;
        $this->settingsHelper = $settingsHelper;
        $this->countryModel = $countryModel;

        parent::__construct($context, $data);

        if (!(bool)$this->_scopeConfig->getValue('qwqer/general/enable')) {
            $this->_template = 'view/order/disabled.phtml';
        }

        $this->orderShippingAddress = $this->getOrder()->getShippingAddress()->getData();
    }

    public function getStoreAddress()
    {
        $sender = $this->settingsHelper->getStoreAddress();

        return implode(', ', array_filter([
            $sender['address'],
            $sender['city'],
            $sender['country'],
            $sender['state'] ?? null,
            $sender['region'] ?? null,
            $sender['zipcode'],
        ]));
    }

    public function getStoreAddressMerged()
    {
        return implode(', ', array_filter([
            $this->orderShippingAddress['street'],
            $this->orderShippingAddress['city'],
            $this->orderShippingAddress['region'],
            $this->orderShippingAddress['postcode'],
            $this->getCountryName($this->orderShippingAddress['country_id']),
        ]));
    }

    public function getCountryName($countryCode)
    {
        return $this->countryModel->loadByCode($countryCode)->getName();
    }

    public function getOrder()
    {
        return $this->_coreRegistry->registry('current_order');
    }

    public function getTabLabel()
    {
        return __('Ship by QWQER');
    }

    public function getTabTitle()
    {
        return __('Ship by QWQER');
    }

    public function canShowTab()
    {
        return true;
    }

    public function isHidden()
    {
        return false;
    }
}
