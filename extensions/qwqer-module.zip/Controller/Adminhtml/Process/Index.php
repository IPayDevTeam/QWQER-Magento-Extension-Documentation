<?php

namespace Qwqer\Delivery\Controller\Adminhtml\Process;

use Exception;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Qwqer\Delivery\Helper\Settings;
use Qwqer\Delivery\Helper\Request;

class Index extends Action implements HttpPostActionInterface
{
    /** @var JsonFactory */
    protected $jsonFactory;

    /** @var OrderRepositoryInterface */
    protected $orderRepository;

    /** @var Settings */
    protected $settingsHelper;

    /** @var Request */
    protected $requestHelper;

    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        OrderRepositoryInterface $orderRepository,
        Settings $settingsHelper,
        Request $requestHelper
    )
    {
        parent::__construct($context);

        $this->jsonFactory = $jsonFactory;
        $this->orderRepository = $orderRepository;
        $this->settingsHelper = $settingsHelper;
        $this->requestHelper = $requestHelper;
    }

    public function execute()
    {
        // Request validations
        try {
            if (!$this->getRequest()->getParam('orderId')) {
                throw new Exception('Order ID is not provided');
            }
        } catch (Exception $exception) {
            return $this->jsonFactory->create()->setData([
                'error' => $exception->getMessage(),
            ]);
        }


        // Order
        $order = $this->orderRepository->get($this->getRequest()->getParam('orderId'));
        if (!$order) {
            return $this->jsonFactory->create()->setData([
                'error' => 'Order not found',
            ]);
        }


        // QWQER Settings and credentials
        $settings = $this->settingsHelper->getSettings();


        // Post data
        $post = (array)$this->getRequest()->getPost();


        // Login to QWQER Api
        try {
            $loginResponse = $this->requestHelper->post('/api/xr/mch/login', [
                'login' => $settings['login'],
                'passw' => $settings['password'],
            ]);
        } catch (Exception $exception) {
            return $this->jsonFactory->create()->setData([
                'error' => $exception->getMessage(),
            ]);
        }


        // Logged session token
        $token = $loginResponse['data']['restid'];


        // Create shipping order in QWQER
        try {
            $deliveryCreateResponse = $this->requestHelper->post('/api/xr/mch/delivery', [
                'distance' => $post['distance'],
                'dunit' => 'METER',
                'dkind' => 'NONE',
                'country' => $post['sender']['countrycode2'],
                'duration' => $post['duration'],
                'summa' => $post['price'] - ($post['discount'] ?? 0),
                'sender' => $post['sender'],
                'receiver' => $post['receiver'],
                'ordersize' => $post['ordersize'],
                'status' => 1,
            ], [
                "Authorization: Bearer {$token}",
            ]);
        } catch (Exception $exception) {
            return $this->jsonFactory->create()->setData([
                'error' => $exception->getMessage(),
            ]);
        }


        // Make payment
        try {
            $this->requestHelper->post('/api/xr/mch/delivery_payment', [
                'id' => $deliveryCreateResponse['data']['id'],
            ], [
                "Authorization: Bearer {$token}",
            ]);
        } catch (Exception $exception) {
            return $this->jsonFactory->create()->setData([
                'error' => $exception->getMessage(),
            ]);
        }


        // Return response result as JSON Data
        return $this->jsonFactory->create()->setData([
            'data' => [
                'status' => (int)$deliveryCreateResponse['data']['status'],
            ],
        ]);
    }
}
