<?php

namespace Qwqer\Delivery\Controller\Adminhtml\Calculate;

use Exception;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Sales\Api\OrderRepositoryInterface;
use Qwqer\Delivery\Helper\Settings;
use Qwqer\Delivery\Helper\Request;

class Index extends Action implements HttpPostActionInterface
{
    /** @var JsonFactory */
    protected $jsonFactory;

    /** @var OrderRepositoryInterface */
    protected $orderRepository;

    /** @var ScopeConfigInterface */
    protected $scopeConfig;

    /** @var Settings */
    protected $settingsHelper;

    /** @var Request */
    protected $requestHelper;

    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        OrderRepositoryInterface $orderRepository,
        ScopeConfigInterface $scopeConfig,
        Settings $settingsHelper,
        Request $requestHelper
    )
    {
        parent::__construct($context);

        $this->jsonFactory = $jsonFactory;
        $this->orderRepository = $orderRepository;
        $this->scopeConfig = $scopeConfig;
        $this->settingsHelper = $settingsHelper;
        $this->requestHelper = $requestHelper;
    }

    public function execute()
    {
        // Request validations
        try {
            if (!$this->getRequest()->getParam('orderId')) {
                throw new Exception('Order ID is not provided');
            }

            if (!$this->getRequest()->getParam('address')) {
                throw new Exception('Address not provided');
            }
            if (!$this->getRequest()->getParam('country')) {
                throw new Exception('Country not provided');
            }
            if (!$this->getRequest()->getParam('countrycode2')) {
                throw new Exception('Country ISO-2 not provided');
            }
            if (!$this->getRequest()->getParam('city')) {
                throw new Exception('City not provided');
            }
            if (!$this->getRequest()->getParam('zipcode')) {
                throw new Exception('ZIP-code not provided');
            }
        } catch (Exception $exception) {
            return $this->jsonFactory->create()->setData([
                'error' => $exception->getMessage(),
            ]);
        }


        // Order
        $order = $this->orderRepository->get($this->getRequest()->getParam('orderId'));
        if (!$order) {
            return $this->jsonFactory->create()->setData([
                'error' => 'Order not found',
            ]);
        }


        // Order shipping address
        $orderShippingAddress = $order->getShippingAddress()->getData();


        // QWQER Settings and credentials
        $settings = $this->settingsHelper->getSettings();


        // Sender Address field
        $sender = $this->settingsHelper->getStoreAddress();
        $sender_address = array_filter([
            $sender['address'],
            $sender['city'],
            $sender['country'],
            $sender['state'] ?? null,
            $sender['region'] ?? null,
            $sender['zipcode'],
        ]);


        // Receiver Address field
        $receiver = (array)$this->getRequest()->getPost();
        $receiver_address = array_filter([
            $receiver['address'],
            $receiver['city'],
            $receiver['country'],
            $receiver['state'] ?? null,
            $receiver['region'] ?? null,
            $receiver['zipcode'],
        ]);


        // Login to QWQER Api
        try {
            $loginResponse = $this->requestHelper->post('/api/xr/mch/login', [
                'login' => $settings['login'],
                'passw' => $settings['password'],
            ]);
        } catch (Exception $exception) {
            return $this->jsonFactory->create()->setData([
                'error' => $exception->getMessage(),
            ]);
        }


        // Logged session token
        $token = $loginResponse['data']['restid'];


        // Get shipping order price from QWQER Api
        try {
            $deliveryOrderPriceResponse = $this->requestHelper->post('/api/xr/mch/delivery_price', [
                'sender' => array_merge([
                    'name' => $this->settingsHelper->getConfig()->getValue('trans_email/ident_general/name'),
                    'phone' => $this->settingsHelper->getConfig()->getValue('general/store_information/phone'),
                    'contact' => $this->settingsHelper->getConfig()->getValue('general/store_information/phone'),
                    'email' => $this->settingsHelper->getConfig()->getValue('trans_email/ident_general/email'),
                    'company' => $this->settingsHelper->getConfig()->getValue('general/store_information/name'),
                ], $sender, [
                    'address' => implode(', ', $sender_address),
                ]),
                'receiver' => array_merge([
                    'name' => trim($orderShippingAddress['firstname'] . ' ' . $orderShippingAddress['lastname']),
                    'contact' => $orderShippingAddress['telephone'],
                    'phone' => $orderShippingAddress['telephone'],
                    'email' => $orderShippingAddress['email'],
                    'company' => $orderShippingAddress['company'],
                ], $receiver, [
                    'address' => implode(', ', $receiver_address),
                ]),
                // @TODO add parcel sizes
                'ordersize' => [
                    'length' => 0,
                    'width' => 0,
                    'height' => 0,
                    'weight' => 1, // @TODO improve it, just count all products weight
                    'lenunit' => 'CENTIMETER',
                    'weightunit' => 'KILOGRAM',
                ],
            ], [
                "Authorization: Bearer {$token}",
            ]);
        } catch (Exception $exception) {
            return $this->jsonFactory->create()->setData([
                'error' => $exception->getMessage(),
            ]);
        }


        // Return response result as JSON Data
        return $this->jsonFactory->create()->setData([
            'data' => [
                'price' => (float)$deliveryOrderPriceResponse['data']['price'],
                'currency' => $deliveryOrderPriceResponse['data']['currency'],
                'response' => $deliveryOrderPriceResponse['data'],
            ],
        ]);
    }
}
